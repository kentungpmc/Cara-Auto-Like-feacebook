<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


<head title="Welcome to Facebook"><title>Selamat datang di Facebook</title><meta name="description" content="Facebook helps you connect and share with the people in your life." /><meta name="referrer" content="default" id="meta_referrer" /><noscript><meta http-equiv="X-Frame-Options" content="deny" /></noscript><style type="text/css">/*<![CDATA[*/.nontouch .mobile-login-field .input{width:90%}
.mobile-login-field-email{direction:ltr}
#footer .acg{background:#fff}._fco #header td{padding:2px;vertical-align:middle}
._fco .other-links{line-height:2em}
._fco .button_area .btnC{color:#fff}
._fco .button_area .btnR{background-color:#b9b9b9;color:#000}
._fco .button_area .btnR:hover{background-color:#999;color:#000}
._fcp div.button_area{width:89%}
._fcp #form_fields > div > div{padding:0 3px 0 0}
._fcp .button_area .largeBtn{padding:5px}
._4u99{color:#87898c;font-size:13px;font-weight:700;padding:5px 0 0 4px}
._4u9a #login_form hr{display:none}
._4u9a ._4u9b, ._4u9a ._4u9b .button_area, ._4u9a ._4u9b ._4u99{background-color:#fbfbfb}
._4u9a ._4u9b{border-bottom:1px solid #fff;border-top:1px solid #cacdd3;margin-top:7px;padding-bottom:10px;padding-top:7px}
._4u9a .other-links{border-bottom:1px solid #cacdd3}
._4u9a #footer{background-color:#eceff5;padding-top:6px}
._4u9a #footer div{background-color:#eceff5}
._4u9a._4u9c ._4u9b{border-bottom:0;padding-bottom:0}
._4u9a._4u9c #footer, ._4u9a._4u9c #footer div, ._4u9a._4u9c .other-links{background-color:#fbfbfb}form{margin:0;border:0}.acw{background-color:#fff}
.acbk{background-color:#000}
.acb{background-color:#3b5998}
.aclb{background-color:#eceff5}
.acdb{background-color:#31394a}
.acg{background-color:#f2f2f2}
.acy{background-color:#fffbe2;color:#7f7212}
.acr{background-color:#ffebe8;color:#6d220d}.aps{padding:2px 3px}
.apm{padding:4px 3px}
.apl{padding:6px 3px}.input{border:solid 1px #999;border-top-color:#888;margin:0;padding:3px}
.nontouch .input{padding:3px 3px 4px 0}.btn{border:solid 2px;cursor:pointer;margin:0;padding:2px 6px 3px;text-align:center}
.btn.largeBtn{display:block}
button.largeBtn,
input.largeBtn{width:100%}
.btnForm{display:inline;border:none;padding:0}
.btnD,
.acb .btnC,
.btnI,
.nontouch a.btnD,
.nontouch .acb a.btnC,
.nontouch a.btnI{background:#f3f4f5;border-color:#ccc #aaa #999;color:#505c77}
.acb .btnD,
.btnC,
.acb .btnI,
.nontouch .acb a.btnD,
.nontouch a.btnC,
.nontouch .acb a.btnI{background:#5b74a8;border-color:#8a9ac5 #29447E #1a356e;color:#fff}
.btnS,
.nontouch a.btnS{background:#69a74e;border-color:#98c37d #3b6e22 #2c5115;color:#fff}
.btnN,
.nontouch a.btnN{background:#ee3f10;border-color:#f48365 #8d290e #762610;color:#fff}.btn,
.btnForm{display:inline-block}
.btn + .btn,
.btnForm + .btnForm,
.btn + .btnForm,
.btnForm + .btn{margin-left:3px}
.largeBtn + .largeBtn{margin-left:0;margin-top:6px}
.btn input{background:none;border:none;margin:0;padding:0}
.btnD input,
.acb .btnC input,
.btnI input{color:#505c77}
.acb .btnD input,
.btnC input,
.acb .btnI input,
.btnS input,
.btnN input{color:#fff}.nontouch a,
.nontouch a:visited{color:#3b5998;text-decoration:none}
.nontouch .sub,
.nontouch .sub:visited{color:gray}
.nontouch .sec,
.nontouch .sec:visited{color:#6d84b4}
.nontouch .inv,
.nontouch .inv:visited{color:#fff}.nontouch a:focus,
.nontouch a:hover,
.nontouch .sub:focus,
.nontouch .sub:hover,
.nontouch .sec:focus,
.nontouch .sec:hover{background-color:#3b5998;color:#fff}
.nontouch .inv:focus,
.nontouch .inv:hover{background-color:#fff;color:#3b5998}.fcb{color:#000}
.fcg{color:gray}
.fcw{color:#fff}
.fcl{color:#3b5998}
.fcs{color:#6d84b4}.mfsxs{font-size:x-small}
.mfss{font-size:small}
body, tr, input, textarea, .mfsm{font-size:medium}
.mfsl{font-size:large}._fcm #header .btn{background-color:#69a74e;border-color:#98c37d #3b6e22 #2c5115}
._fcn #header .btn{background-color:#b9b9b9;border-color:#D5D5D5 #909090 #757575;color:#000}.mBasicOnDesktop{margin:0 auto;max-width:600px}.lr{width:100%}
.lr .r{text-align:right}.img{border:0;display:inline-block;vertical-align:top}
i.img u{position:absolute;width:0;height:0;overflow:hidden}.abt{border-top:1px solid}
.abb{border-bottom:1px solid}
.acw{border-color:#e9e9e9}
.acb{border-color:#1d4088}
.aclb{border-color:#d8dfea}
.acg{border-color:#ccc}
.acy{border-color:#e2c822}
.acr{border-color:#dd3c10}body{margin:0;padding:0;text-align:left;direction:ltr}
body, tr, input, textarea, button{font-family:sans-serif}/*]]>*/</style><script>window.localStorage&&window.localStorage.clear();</script></head><body class="nontouch acw"><div class="mfsm"><div id="viewport" class="mBasicOnDesktop"><div id="root" tabindex="0" role="main" class="_fco _fcm acw"><div class="acb aps" id="header"><table cellspacing="0" cellpadding="0" class="lr"><tr><td valign="top"><a href="http://m.facebook.com/login.php"><img src="http://static.ak.fbcdn.net/rsrc.php/v2/yz/r/aKhO2tw3FnO.png" width="76" height="20" class="img" alt="facebook" /></a></td><td valign="top" class="r"><a class="btn btnI" href="http://m.facebook.com/r.php">Mendaftar</a></td></tr></table></div><div id="objects_container"><div class="acy aps abb"><span class="mfss">Anda harus masuk dulu.</span></div><div class="aclb"><div class="loginInner"><div class="acy apl abt abb"><a href="http://m.facebook.com/fbapp/d/facebook.jad">Dapatkan Facebook Seluler dan menjelajah lebih cepat.</a></div><form method="post" class="mobile-login-form _fcp" id="login_form" novalidate="1" action="login.php"><input type="hidden" name="lsd" value="AVrxuZUG" autocomplete="off" /><input type="hidden" name="charset_test" value="��,´,��,´,水,�,�" /><input type="hidden" name="version" value="1" /><input type="hidden" id="ajax" name="ajax" value="0" /><input type="hidden" id="width" name="width" value="0" /><input type="hidden" id="pxr" name="pxr" value="0" /><input type="hidden" id="gps" name="gps" value="0" /><input type="hidden" autocomplete="off" name="m_ts" value="1359915674" /><input type="hidden" autocomplete="off" name="li" value="mqoOUZbnCMAWYkzOEY7RIQB-" /><input type="hidden" autocomplete="off" name="signup_layout" value="layout|bottom_clean||wider_form||prmnt_btn|special||st|create||header_button||hdbtn_color|green||Feb1" /><input type="hidden" autocomplete="off" name="laststage" value="first" /><div id="form_fields"><div class="mobile-login-field mobile-login-field-email aclb apl"><div>Email atau Telepon<br /><input class="input" autocorrect="off" autocapitalize="off" name="email" type="text" /></div></div><div class="mobile-login-field aclb apl"><div>Kata Sandi<br /><input class="input" autocorrect="off" autocapitalize="off" name="pass" type="password" /></div></div></div><div class="button_area aclb apl"><input value="Masuk" type="submit" name="login" class="btn btnC largeBtn" size="0" /></div><hr style="background-color:#cccccc;height:1px;border:0px solid #fff;margin:0.3em auto;width:100%;" /><div class="_4u9b aclb"><div class="button_area aclb apl"><a class="btn btnS largeBtn" href="http://m.facebook.com/r.php">Buat Akun Baru</a></div></div><noscript><input type="hidden" autocomplete="off" name="_fb_noscript" value="true" /></noscript></form><div class="other-links aclb apl"><span class="mfsm fcg"><a href="http://m.facebook.com/login/identify">Lupa kata sandi?</a><br /><a href="http://m.facebook.com/help">Pusat Bantuan</a></span></div></div></div></div><div id="footer"><div class="acg apm"><span class="mfss fcg"><b>Bahasa Indonesia</b>�<span role="separator" aria-hidden="true">�</span>�<a class="sec" href="http://m.facebook.com/index.php?refsrc=http%3A%2F%2Fm.facebook.com%2Findex.php&_rdr">English (US)</a>�<span role="separator" aria-hidden="true">�</span>�<a class="sec" href="http://m.facebook.com/index.php?refsrc=http%3A%2F%2Fm.facebook.com%2Fa%2Flanguage.php&_rdr">Espa�ol</a>�<span role="separator" aria-hidden="true">�</span>�<a class="sec" href="http://m.facebook.com/language.php?n=http%3A%2F%2Fm.facebook.com%2Findex.php&refid=8">Lainnya...</a></span></div><div class="acg apm"><span class="mfss fcg">Facebook � 2013</span></div><div class="acg apm"><span class="mfss fcg"><a href="http://wap.indosat.com"> FB SMS tanpa batas ketik FB kirim ke 32665</ a></span></div></div></div></div><input type="hidden" id="m_user_DEPRECATED" value="0" /><div id="static_templates"></div></div></body></html>